package dio.padroesprojetos.padroesprojetosspting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PadroesProjetosSptingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PadroesProjetosSptingApplication.class, args);
	}

}
